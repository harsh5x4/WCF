﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        SR.MyServiceClient Obj = new SR.MyServiceClient();
        var BookObj = Obj.GetBookById(Convert.ToInt32(txtSearchBook.Text));
        Response.Write("Id:"+BookObj.Id +"<br>"+"Title:"+ BookObj.Title +"<br>"+"Price:"+ BookObj.Price +"<br>"+ "Year:"+ BookObj.Year +"<br>"+"Genre:"+ BookObj.Genre);
    }
}