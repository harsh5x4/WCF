﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btntransfer_Click(object sender, EventArgs e)
    {
        SR.MyServiceClient TranObj = new SR.MyServiceClient();
        Label1.Text = TranObj.PerformTransfer(Convert.ToInt32(txtfrom.Text),
            Convert.ToInt32(txtto.Text), Convert.ToInt32(txtamt.Text));
        
    }
}