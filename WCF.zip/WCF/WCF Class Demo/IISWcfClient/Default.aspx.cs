﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ServiceModel;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn1_Click(object sender, EventArgs e)
    {
        ServiceReference1.BookServiceClient s = new ServiceReference1.BookServiceClient();
        lbl1.Text = s.DoWork();
    }
    protected void btnShowAll_Click(object sender, EventArgs e)
    {
        ServiceReference1.BookServiceClient Servobj = new ServiceReference1.BookServiceClient();
        grdBook.DataSource = Servobj.GetBooks();
        grdBook.DataBind();
    }


    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ServiceReference1.BookServiceClient Obj = new ServiceReference1.BookServiceClient();
        grdBook.DataSource = Obj.getBookbyID(Convert.ToInt16(txtsearch.Text));
        grdBook.DataBind();
    }
}