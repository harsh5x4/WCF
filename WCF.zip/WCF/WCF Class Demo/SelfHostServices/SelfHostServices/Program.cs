﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;  // reference


namespace SelfHostServices
{
    [ServiceContract]
    public interface IMyService
    {
        [OperationContract]
        string GetDateTime(string name);
    }
    
    public class MyService:IMyService
    {
        public string GetDateTime(string name)
        {
             string d = DateTime.Now.ToLongDateString() + "||" + DateTime.Now.ToLongTimeString();
             return "Hi..." + name + " " + d;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost sh = new ServiceHost(typeof(SelfHostServices.MyService));
            sh.Open();
            Console.WriteLine("Service is Running...");
            Console.ReadLine();
            sh.Close();
        }
    }
}
