﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MyService" in code, svc and config file together.
public class MyService : IMyService
{
	public  string PerformTransfer(int f,int t,int b)
	{
         string status = "";
         SqlTransaction tr;

         string q1 = "update Accounts_138222 set Bal=Bal-" + b + "where Accno=" + f + "";
         string q2 = "update Accounts_138222 set Bal=Bal+" + b + "where Accno=" + t + "";
         SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser");
         con.Open();
         tr = con.BeginTransaction();
        try
        {
            SqlCommand cmd1 = new SqlCommand(q1, con, tr);
            SqlCommand cmd2 = new SqlCommand(q2, con, tr);
            int fr = cmd1.ExecuteNonQuery();
            int sr = cmd2.ExecuteNonQuery();
            if(fr>0 && sr>0)
            {

                tr.Commit();
                status = "Transcation Successful";
           }
            else
            {
                tr.Rollback();
                status = "Transcation Rolled Back";
            }
        }

        catch(Exception ex)
        {
            tr.Rollback();
            status = "Transcation Rolled Back";
        }

         return status;

	}
}
