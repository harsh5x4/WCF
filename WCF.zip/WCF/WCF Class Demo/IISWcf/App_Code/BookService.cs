﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "BookService" in code, svc and config file together.
public class BookService : IBookService
{
	public string DoWork()
	{
        return "Hi....Work is Done.";
	}

    public DataSet GetBooks()
    {
        DataSet ds = new DataSet();
        SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser;");
        SqlCommand cmd = new SqlCommand("Select * from Books_138193", con);
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        da.Fill(ds);  
        return ds;
    }
       
      public DataSet getBookbyID(int id)
    {
        DataSet ds = new DataSet();
        SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser;");
        SqlCommand cmd = new SqlCommand("Select * from Books_138193 where Id="+id +"", con);
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        da.Fill(ds);
        return ds;
    }


}
