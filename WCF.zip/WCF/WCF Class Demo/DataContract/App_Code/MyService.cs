﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MyService" in code, svc and config file together.
public class MyService : IMyService
{
	public Book GetBookById(int id)
	{
        Book b = new Book();
        string q = "select * from Books_138193 where id=" + id + "";
        SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser;");
        SqlCommand cmd = new SqlCommand(q, con);
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while(dr.Read())
        {
            b.Id = Convert.ToInt32(dr["Id"]);
            b.Title=dr[1].ToString();
            b.Price=Convert.ToDecimal(dr[2]);
            b.Year=Convert.ToInt32(dr["Year"]);
            b.Genre=dr[4].ToString();
        }

        return b;
	}
}
