﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.MathClient proxy = new ServiceReference1.MathClient();
            Console.WriteLine(proxy.Add(10,10));
            Console.WriteLine(proxy.Multiply (10,10));
            Console.Read();
        }
    }
}
